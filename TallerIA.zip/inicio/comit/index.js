console.log("1) Definición concisa:");
console.log("Una variable es un nombre que guarda un valor para que el programa lo use.");
console.log("");

console.log("2) Analogía detallada (caja = variable):");
console.log("- Caja = variable: un contenedor donde guardas algo.");
console.log("- Etiqueta = nombre: la marca que te dice qué hay dentro de la caja.");
console.log("- Contenido = valor: lo que realmente está dentro de la caja.");
console.log("- Cerrar/abrir = asignar/leer: pones algo en la caja (asignar) o lo sacas para verlo (leer).");
console.log("- Mover la caja = reasignar: cambias lo que hay dentro o la llevas a otro lugar.");
console.log("- Caja vacía = null/undefined: la etiqueta existe pero no hay contenido.");
console.log("");
console.log("Tres ejemplos cotidianos:");
console.log("1. Mudanza: caja etiquetada 'libros' contiene libros; si la vacías y pones ropa, la reasignaste.");
console.log("2. Cocina: frasco etiquetado 'azúcar' contiene azúcar; si está vacío es como null.");
console.log("3. Oficina: carpeta 'facturas' guarda documentos; cambiar su contenido es reasignar.");
console.log("");

console.log("3) Mini-ejemplo en pseudocódigo:");
console.log("var caja;           // declarar");
console.log("caja = \"libros\";  // asignar");
console.log("caja = \"ropa\";    // reasignar");
console.log("");

console.log("4) Resumen:");
console.log("Ver una variable como una caja con etiqueta ayuda a entender cómo se guarda, cambia y lee la información.");

console.log(`
**HTML de ejemplo (archivo listo para pegar)**:  
- Crea un archivo \`index/commit.html\` o \`index.html\` y pega esto:

\`\`\`html
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>¿Qué es un commit?</title>
  <style>
    :root{
      --bg:#f7f9fc;
      --card:#ffffff;
      --muted:#6b7280;
      --accent:#7dd3fc;
      --accent-2:#a7f3d0;
      --glass: rgba(255,255,255,0.6);
      --radius:14px;
      --shadow: 0 8px 30px rgba(15,23,42,0.06);
      --mono: ui-monospace, SFMono-Regular, Menlo, Monaco, "Roboto Mono", monospace;
      --sans: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    html,body{height:100%}
    body{
      margin:0;
      font-family:var(--sans);
      background: linear-gradient(180deg, var(--bg), #eef6ff 60%);
      display:flex;
      align-items:center;
      justify-content:center;
      padding:40px;
      -webkit-font-smoothing:antialiased;
      color:#0f172a;
    }
    .container{
      width:100%;
      max-width:900px;
      animation:fadeIn 700ms ease both;
    }
    .card{
      background:var(--card);
      border-radius:var(--radius);
      box-shadow:var(--shadow);
      padding:28px;
      border: 1px solid rgba(15,23,42,0.04);
      display:grid;
      gap:18px;
      transform-origin:center;
      transition:transform 220ms ease, box-shadow 220ms ease;
    }
    .card:hover{ transform:translateY(-6px); box-shadow: 0 18px 40px rgba(15,23,42,0.08); }

    h1{ margin:0; font-size:1.6rem; letter-spacing:-0.02em; }
    p.lead{ margin:0; color:var(--muted); font-size:0.98rem; }

    .section{ padding:16px; background:linear-gradient(180deg, rgba(250,250,255,0.6), rgba(250,250,255,0.4)); border-radius:10px; }
    ul{ margin:8px 0 0 18px; color:var(--muted); }
    li{ margin:6px 0; }

    pre.cmd{
      background: linear-gradient(90deg, rgba(2,6,23,0.02), rgba(2,6,23,0.01));
      padding:12px 14px;
      border-radius:10px;
      font-family:var(--mono);
      color:#04263a;
      overflow:auto;
      margin:0;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
    }
    code{ white-space:pre; font-family:var(--mono); font-size:0.95rem; color:#083344; }

    .btn{
      background: linear-gradient(90deg,var(--accent),var(--accent-2));
      color:#02263a;
      border:none;
      padding:8px 12px;
      border-radius:10px;
      cursor:pointer;
      font-weight:600;
      transition:transform 160ms ease, box-shadow 160ms ease, opacity 160ms ease;
      box-shadow: 0 6px 18px rgba(125,211,252,0.18);
    }
    .btn:active{ transform:translateY(1px) scale(0.998); }
    .copied{ opacity:0; font-size:0.9rem; color:green; margin-left:8px; transition:opacity 220ms ease; }
    .show{ opacity:1; }

    @keyframes fadeIn{ from{opacity:0; transform:translateY(8px)} to{opacity:1; transform:none} }

    @media (max-width:640px){
      .card{ padding:18px; }
      h1{ font-size:1.3rem; }
    }
  </style>
</head>
<body>
  <main class="container" role="main">
    <article class="card" aria-labelledby="title">
      <header>
        <h1 id="title">¿Qué es un commit?</h1>
        <p class="lead">Resumen breve y accesible sobre commits y buenas prácticas.</p>
      </header>

      <section class="section" aria-label="Definición">
        <p><strong>Definición:</strong></p>
        <p>Un commit es una instantánea (snapshot) de los cambios en un repositorio de control de versiones (por ejemplo Git). Guarda el estado del árbol de archivos más metadatos: autor, fecha, mensaje y un identificador (hash) único.</p>
      </section>

      <section class="section" aria-label="Importancia">
        <p><strong>Por qué es importante</strong></p>
        <ul>
          <li>Historial: permite ver qué cambió y cuándo.</li>
          <li>Reversión y recuperación: posibilita volver a versiones anteriores o deshacer errores.</li>
          <li>Trazabilidad: liga cambios a autores y a issues/tickets.</li>
          <li>Colaboración: coordina el trabajo entre varias personas (merge, branch, pull request).</li>
          <li>Atomicidad: cada commit debe representar un cambio lógico y coherente.</li>
          <li>Integración continua / despliegue: muchos pipelines se disparan por commits.</li>
        </ul>
      </section>

      <section class="section" aria-label="Buenas prácticas">
        <p><strong>Buenas prácticas (breve)</strong></p>
        <ul>
          <li>Hacer commits pequeños y enfocados.</li>
          <li>Mensajes claros y en imperativo: "Corrige validación de email".</li>
          <li>Incluir referencias a issues cuando aplique.</li>
          <li>Probar antes de commitear.</li>
        </ul>
      </section>

      <section class="section" aria-label="Comando">
        <p><strong>Cómo crear un commit rápido (PowerShell/Git Bash)</strong></p>
        <pre class="cmd" aria-hidden="false">
<code id="gitCmd">git add archivo_o_directorio
git commit -m "Mensaje claro y descriptivo"</code>
<button id="copyBtn" class="btn" aria-label="Copiar comando">Copiar</button>
<span id="copied" class="copied">¡Copiado!</span>
        </pre>
      </section>
    </article>
  </main>

  <script>
    (function(){
      const btn = document.getElementById('copyBtn');
      const gitCmd = document.getElementById('gitCmd').innerText;
      const copied = document.getElementById('copied');

      btn.addEventListener('click', async () => {
        try{
          await navigator.clipboard.writeText(gitCmd);
          copied.classList.add('show');
          setTimeout(()=> copied.classList.remove('show'), 1400);
          btn.animate([{ transform: 'scale(1)' }, { transform: 'scale(0.98)' }, { transform: 'scale(1)' }], { duration: 220 });
        }catch(e){
          // fallback
          const ta = document.createElement('textarea');
          ta.value = gitCmd;
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand('copy'); copied.classList.add('show'); setTimeout(()=>copied.classList.remove('show'),1400); } catch(e){}
          document.body.removeChild(ta);
        }
      });
    })();
  </script>
</body>
</html>
\`\`\`
`);