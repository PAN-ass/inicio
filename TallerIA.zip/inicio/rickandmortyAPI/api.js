const API_URL = 'https://rickandmortyapi.com/api/character';

let allCharacters = [];
let filteredCharacters = [];
let currentPage = 1;
const itemsPerPage = 9;
let allSpecies = new Set();

// Obtener todos los personajes
async function cargarPersonajes(pagina = 1) {
    try {
        mostrarLoading(true);
        ocultarError();
        
        let url = `${API_URL}?page=${pagina}`;
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Error al cargar los personajes');
        }
        
        const data = await response.json();
        
        // Cargar todas las páginas
        let personajes = [...data.results];
        let paginasRestantes = data.info.pages;
        
        for (let i = pagina + 1; i <= paginasRestantes; i++) {
            const respuesta = await fetch(`${API_URL}?page=${i}`);
            const datosAdicionales = await respuesta.json();
            personajes = [...personajes, ...datosAdicionales.results];
        }
        
        allCharacters = personajes;
        filteredCharacters = [...allCharacters];
        
        // Obtener especies únicas
        extraerEspecies();
        
        // Renderizar
        currentPage = 1;
        renderizarPersonajes();
        renderizarPaginacion();
        mostrarLoading(false);
        
    } catch (error) {
        console.error('Error:', error);
        mostrarError('Error al cargar los personajes. Intenta de nuevo.');
        mostrarLoading(false);
    }
}

// Extraer todas las especies únicas
function extraerEspecies() {
    allSpecies.clear();
    allCharacters.forEach(personaje => {
        if (personaje.species) {
            allSpecies.add(personaje.species);
        }
    });
    
    // Llenar el select de especies
    const speciesSelect = document.getElementById('speciesFilter');
    const especiesOrdenadasArray = Array.from(allSpecies).sort();
    
    especiesOrdenadasArray.forEach(especie => {
        const option = document.createElement('option');
        option.value = especie;
        option.textContent = especie;
        speciesSelect.appendChild(option);
    });
}

// Buscar personajes por nombre
function buscarPersonajes() {
    const searchInput = document.getElementById('searchInput');
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    if (searchTerm === '') {
        filteredCharacters = [...allCharacters];
    } else {
        filteredCharacters = allCharacters.filter(personaje => 
            personaje.name.toLowerCase().includes(searchTerm)
        );
    }
    
    currentPage = 1;
    renderizarPersonajes();
    renderizarPaginacion();
}

// Aplicar filtros
function aplicarFiltros() {
    const statusFilter = document.getElementById('statusFilter').value;
    const speciesFilter = document.getElementById('speciesFilter').value;
    const searchInput = document.getElementById('searchInput').value.toLowerCase().trim();
    
    let resultado = [...allCharacters];
    
    // Filtrar por búsqueda
    if (searchInput !== '') {
        resultado = resultado.filter(personaje => 
            personaje.name.toLowerCase().includes(searchInput)
        );
    }
    
    // Filtrar por estado
    if (statusFilter !== '') {
        resultado = resultado.filter(personaje => 
            personaje.status === statusFilter
        );
    }
    
    // Filtrar por especie
    if (speciesFilter !== '') {
        resultado = resultado.filter(personaje => 
            personaje.species === speciesFilter
        );
    }
    
    filteredCharacters = resultado;
    currentPage = 1;
    renderizarPersonajes();
    renderizarPaginacion();
}

// Renderizar personajes en la página actual
function renderizarPersonajes() {
    const container = document.getElementById('charactersContainer');
    const noResults = document.getElementById('noResults');
    
    if (filteredCharacters.length === 0) {
        container.innerHTML = '';
        noResults.style.display = 'block';
        document.getElementById('paginationContainer').innerHTML = '';
        return;
    }
    
    noResults.style.display = 'none';
    
    const inicio = (currentPage - 1) * itemsPerPage;
    const fin = inicio + itemsPerPage;
    const personajesPagina = filteredCharacters.slice(inicio, fin);
    
    container.innerHTML = personajesPagina.map(personaje => `
        <div class="character-card">
            <img src="${personaje.image}" alt="${personaje.name}" loading="lazy">
            <div class="character-info">
                <h2>${personaje.name}</h2>
                
                <div class="status ${personaje.status.toLowerCase()}">
                    ${personaje.status}
                </div>
                
                <div class="info-row">
                    <span class="info-label">Especie:</span>
                    <span class="info-value">${personaje.species}</span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Ubicación:</span>
                    <span class="info-value">${personaje.location.name}</span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Origen:</span>
                    <span class="info-value">${personaje.origin.name}</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Renderizar controles de paginación
function renderizarPaginacion() {
    const container = document.getElementById('paginationContainer');
    const totalPaginas = Math.ceil(filteredCharacters.length / itemsPerPage);
    
    if (totalPaginas <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    // Botón anterior
    paginationHTML += `
        <button 
            onclick="cambiarPagina(${currentPage - 1})" 
            ${currentPage === 1 ? 'disabled' : ''}
        >
            ← Anterior
        </button>
    `;
    
    // Números de página
    for (let i = 1; i <= totalPaginas; i++) {
        if (i === 1 || i === totalPaginas || (i >= currentPage - 1 && i <= currentPage + 1)) {
            paginationHTML += `
                <button 
                    onclick="cambiarPagina(${i})"
                    class="${i === currentPage ? 'active' : ''}"
                >
                    ${i}
                </button>
            `;
        } else if (i === currentPage - 2 || i === currentPage + 2) {
            paginationHTML += '<span style="color: white; padding: 10px 5px;">...</span>';
        }
    }
    
    // Botón siguiente
    paginationHTML += `
        <button 
            onclick="cambiarPagina(${currentPage + 1})" 
            ${currentPage === totalPaginas ? 'disabled' : ''}
        >
            Siguiente →
        </button>
    `;
    
    container.innerHTML = paginationHTML;
}

// Cambiar página
function cambiarPagina(pagina) {
    const totalPaginas = Math.ceil(filteredCharacters.length / itemsPerPage);
    
    if (pagina < 1 || pagina > totalPaginas) {
        return;
    }
    
    currentPage = pagina;
    renderizarPersonajes();
    renderizarPaginacion();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Mostrar/ocultar loading
function mostrarLoading(mostrar) {
    document.getElementById('loading').style.display = mostrar ? 'block' : 'none';
}

// Mostrar error
function mostrarError(mensaje) {
    const errorDiv = document.getElementById('error');
    errorDiv.textContent = mensaje;
    errorDiv.style.display = 'block';
}

// Ocultar error
function ocultarError() {
    document.getElementById('error').style.display = 'none';
}

// Event listeners
document.getElementById('searchInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        buscarPersonajes();
    }
});

// Cargar personajes al iniciar
cargarPersonajes(1);
