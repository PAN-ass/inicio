// Variables globales
const API_BASE_URL = 'https://dog.ceo/api';
const ITEMS_PER_PAGE = 6;

let allBreeds = [];
let filteredBreeds = [];
let currentPage = 1;

// Elementos del DOM
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const dogsGrid = document.getElementById('dogsGrid');
const pagination = document.getElementById('pagination');
const loading = document.getElementById('loading');
const errorMessage = document.getElementById('errorMessage');

// Event listeners
searchBtn.addEventListener('click', handleSearch);
searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        handleSearch();
    }
});

// Función para obtener todas las razas de perros
async function fetchAllBreeds() {
    try {
        showLoading(true);
        const response = await fetch(`${API_BASE_URL}/breeds/list/all`);
        
        if (!response.ok) {
            throw new Error('Error al obtener las razas de perros');
        }

        const data = await response.json();

        if (data.status === 'success') {
            // Convertir objeto de razas en array plano
            allBreeds = [];
            for (const [breed, subBreeds] of Object.entries(data.message)) {
                if (subBreeds.length > 0) {
                    subBreeds.forEach(subBreed => {
                        allBreeds.push({
                            name: `${breed} - ${subBreed}`,
                            breed: breed,
                            subBreed: subBreed,
                            displayName: `${capitalizeFirstLetter(subBreed)} ${capitalizeFirstLetter(breed)}`
                        });
                    });
                } else {
                    allBreeds.push({
                        name: breed,
                        breed: breed,
                        subBreed: null,
                        displayName: capitalizeFirstLetter(breed)
                    });
                }
            }

            // Ordenar alfabéticamente
            allBreeds.sort((a, b) => a.displayName.localeCompare(b.displayName));
            
            filteredBreeds = [...allBreeds];
            currentPage = 1;
            renderBreeds();
        }
    } catch (error) {
        showError('Error al cargar las razas de perros: ' + error.message);
        console.error('Error:', error);
    } finally {
        showLoading(false);
    }
}

// Función para buscar razas
function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase().trim();

    if (searchTerm === '') {
        filteredBreeds = [...allBreeds];
    } else {
        filteredBreeds = allBreeds.filter(breed => 
            breed.displayName.toLowerCase().includes(searchTerm)
        );
    }

    currentPage = 1;
    renderBreeds();
}

// Función para obtener imagen de la raza
async function getBreedImage(breed, subBreed = null) {
    try {
        const url = subBreed 
            ? `${API_BASE_URL}/breed/${breed}/${subBreed}/images/random`
            : `${API_BASE_URL}/breed/${breed}/images/random`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.status === 'success') {
            return data.message;
        }
        return 'https://via.placeholder.com/300x250?text=No+image';
    } catch (error) {
        console.error('Error fetching image:', error);
        return 'https://via.placeholder.com/300x250?text=No+image';
    }
}

// Función para renderizar las tarjetas de razas
async function renderBreeds() {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const paginatedBreeds = filteredBreeds.slice(start, end);

    if (paginatedBreeds.length === 0) {
        dogsGrid.innerHTML = '<div class="no-results">No se encontraron razas de perros</div>';
        pagination.innerHTML = '';
        return;
    }

    showLoading(true);
    dogsGrid.innerHTML = '';

    try {
        // Obtener imágenes para todas las razas en paralelo
        const cardPromises = paginatedBreeds.map(async (breed) => {
            const imageUrl = await getBreedImage(breed.breed, breed.subBreed);
            return createBreedCard(breed, imageUrl);
        });

        const cards = await Promise.all(cardPromises);
        dogsGrid.innerHTML = cards.join('');
    } catch (error) {
        showError('Error al renderizar las tarjetas: ' + error.message);
    } finally {
        showLoading(false);
        renderPagination();
    }
}

// Función para crear una tarjeta de raza
function createBreedCard(breed, imageUrl) {
    return `
        <div class="card">
            <img src="${imageUrl}" alt="${breed.displayName}" class="card-image">
            <div class="card-content">
                <h3 class="card-title">${breed.displayName}</h3>
                <div class="card-info">
                    <div class="info-item">
                        <span class="info-label">Raza:</span>
                        <span class="info-value">${capitalizeFirstLetter(breed.breed)}</span>
                    </div>
                    ${breed.subBreed ? `
                        <div class="info-item">
                            <span class="info-label">Subtipo:</span>
                            <span class="info-value">${capitalizeFirstLetter(breed.subBreed)}</span>
                        </div>
                    ` : ''}
                    <div class="info-item">
                        <span class="info-label">Origen:</span>
                        <span class="info-value">${getBreedOrigin(breed.breed)}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Función para renderizar la paginación
function renderPagination() {
    const totalPages = Math.ceil(filteredBreeds.length / ITEMS_PER_PAGE);
    pagination.innerHTML = '';

    if (totalPages <= 1) {
        return;
    }

    // Botón anterior
    const prevBtn = document.createElement('button');
    prevBtn.className = 'pagination-btn';
    prevBtn.textContent = '← Anterior';
    prevBtn.disabled = currentPage === 1;
    prevBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderBreeds();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });
    pagination.appendChild(prevBtn);

    // Números de página
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    if (startPage > 1) {
        const firstBtn = document.createElement('button');
        firstBtn.className = 'pagination-btn';
        firstBtn.textContent = '1';
        firstBtn.addEventListener('click', () => {
            currentPage = 1;
            renderBreeds();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        pagination.appendChild(firstBtn);

        if (startPage > 2) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.color = 'white';
            dots.style.padding = '10px';
            pagination.appendChild(dots);
        }
    }

    for (let i = startPage; i <= endPage; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = 'pagination-btn';
        if (i === currentPage) {
            pageBtn.classList.add('active');
        }
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', () => {
            currentPage = i;
            renderBreeds();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        pagination.appendChild(pageBtn);
    }

    if (endPage < totalPages) {
        if (endPage < totalPages - 1) {
            const dots = document.createElement('span');
            dots.textContent = '...';
            dots.style.color = 'white';
            dots.style.padding = '10px';
            pagination.appendChild(dots);
        }

        const lastBtn = document.createElement('button');
        lastBtn.className = 'pagination-btn';
        lastBtn.textContent = totalPages;
        lastBtn.addEventListener('click', () => {
            currentPage = totalPages;
            renderBreeds();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        pagination.appendChild(lastBtn);
    }

    // Botón siguiente
    const nextBtn = document.createElement('button');
    nextBtn.className = 'pagination-btn';
    nextBtn.textContent = 'Siguiente →';
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderBreeds();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    });
    pagination.appendChild(nextBtn);
}

// Función auxiliar para capitalizar texto
function capitalizeFirstLetter(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Función para obtener el origen de la raza (basado en datos comunes)
function getBreedOrigin(breed) {
    const breedOrigins = {
        'labrador': 'Canadá',
        'retriever': 'Canadá/Reino Unido',
        'poodle': 'Francia',
        'bulldog': 'Inglaterra',
        'german': 'Alemania',
        'french': 'Francia',
        'english': 'Inglaterra',
        'siberian': 'Rusia',
        'husky': 'Rusia',
        'shiba': 'Japón',
        'akita': 'Japón',
        'dachshund': 'Alemania',
        'corgi': 'Gales',
        'boxer': 'Alemania',
        'beagle': 'Inglaterra',
        'dalmatian': 'Croacia',
        'australian': 'Australia',
        'rottweiler': 'Alemania',
        'pitbull': 'Estados Unidos',
        'chihuahua': 'México',
        'maltese': 'Malta',
        'yorkshire': 'Inglaterra',
        'pug': 'China',
        'chow': 'China',
        'shar': 'China',
        'spaniel': 'España',
        'collie': 'Escocia',
        'greyhound': 'Antiguo Egipto',
        'pinscher': 'Alemania',
        'schnauzer': 'Alemania',
        'terrier': 'Varias',
        'setter': 'Irlanda/Inglaterra',
        'pointer': 'Inglaterra/España',
        'papillon': 'Francia',
        'bichon': 'Francia',
        'basenji': 'África',
        'saluki': 'Oriente Medio',
        'afghan': 'Afganistán'
    };

    const breedLower = breed.toLowerCase();
    for (const [key, origin] of Object.entries(breedOrigins)) {
        if (breedLower.includes(key)) {
            return origin;
        }
    }
    
    return 'Desconocido';
}

// Funciones auxiliares para mostrar/ocultar elementos
function showLoading(show) {
    if (show) {
        loading.classList.add('active');
    } else {
        loading.classList.remove('active');
    }
}

function showError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.add('active');
    setTimeout(() => {
        errorMessage.classList.remove('active');
    }, 5000);
}

// Inicializar la aplicación cuando carga el DOM
document.addEventListener('DOMContentLoaded', () => {
    fetchAllBreeds();
});
